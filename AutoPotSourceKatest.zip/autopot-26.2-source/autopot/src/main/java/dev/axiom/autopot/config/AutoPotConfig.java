package dev.axiom.autopot.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.axiom.autopot.AutoPotMod;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class AutoPotConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("autopot.json");

    public float minHealthHearts = 4.0f;
    public int switchDelayTicks = 0;
    public int throwDelayTicks = 0;
    public boolean lookDown = true;
    public boolean switchBack = true;
    public int requiredPotions = 2;

    public static void load() {
        AutoPotConfig config = new AutoPotConfig();
        if (Files.exists(CONFIG_PATH)) {
            try (Reader reader = Files.newBufferedReader(CONFIG_PATH)) {
                AutoPotConfig loaded = GSON.fromJson(reader, AutoPotConfig.class);
                if (loaded != null) config = loaded;
            } catch (IOException | RuntimeException exception) {
                AutoPotMod.LOGGER.error("[AutoPot] Could not read config; using defaults", exception);
            }
        }
        config.minHealthHearts = Math.max(0.5f, Math.min(10.0f, config.minHealthHearts));
        config.switchDelayTicks = Math.max(0, Math.min(20, config.switchDelayTicks));
        config.throwDelayTicks = Math.max(0, Math.min(20, config.throwDelayTicks));
        config.requiredPotions = Math.max(1, Math.min(9, config.requiredPotions));
        AutoPotMod.minHealthHearts = config.minHealthHearts;
        AutoPotMod.switchDelayTicks = config.switchDelayTicks;
        AutoPotMod.throwDelayTicks = config.throwDelayTicks;
        AutoPotMod.lookDown = config.lookDown;
        AutoPotMod.switchBack = config.switchBack;
        AutoPotMod.requiredPotions = config.requiredPotions;
        save(config);
    }

    private static void save(AutoPotConfig config) {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(CONFIG_PATH)) {
                GSON.toJson(config, writer);
            }
        } catch (IOException exception) {
            AutoPotMod.LOGGER.error("[AutoPot] Could not save config", exception);
        }
    }
}
