package dev.axiom.autopot;

import com.mojang.blaze3d.platform.InputConstants;
import dev.axiom.autopot.config.AutoPotConfig;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.minecraft.core.Holder;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.core.component.DataComponents;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public final class AutoPotMod implements ClientModInitializer {
    public static final String MOD_ID = "autopot";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static KeyMapping activateKey;

    public static float minHealthHearts = 4.0f;
    public static int switchDelayTicks = 0;
    public static int throwDelayTicks = 0;
    public static boolean lookDown = true;
    public static boolean switchBack = true;
    public static int requiredPotions = 2;

    private boolean activated;
    private int potThrown;
    private int neededPots = 2;
    private int currentSlot = -1;
    private int targetSlot = -1;
    private int originalSlot = -1;
    private float originalPitch;
    private boolean pitchSaved;
    private int switchCounter;
    private int throwCounter;
    private final List<Integer> hotbarSlots = new ArrayList<>();

    @Override
    public void onInitializeClient() {
        activateKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.autopot.activate",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_G,
                "category.autopot"
        ));
        AutoPotConfig.load();
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        LOGGER.info("[AutoPot] Initialised for Minecraft 26.2");
    }

    private void tick(Minecraft mc) {
        if (mc.player == null || mc.level == null) {
            if (activated) reset(mc, false);
            return;
        }

        while (activateKey.consumeClick()) tryActivate(mc);
        if (!activated) return;

        if (mc.player.getHealth() > minHealthHearts * 2.0f) {
            reset(mc, true);
            return;
        }

        hotbarSlots.clear();
        hotbarSlots.addAll(findSplashHealthIISlots(mc));
        if (hotbarSlots.size() < neededPots) {
            reset(mc, true);
            return;
        }

        if (lookDown && !pitchSaved) {
            originalPitch = mc.player.getXRot();
            mc.player.setXRot(90.0f);
            pitchSaved = true;
        }

        if (currentSlot != targetSlot) {
            if (switchCounter < switchDelayTicks) {
                switchCounter++;
                return;
            }
            switchSlot(mc, targetSlot);
            currentSlot = targetSlot;
            switchCounter = 0;
            return;
        }

        if (potThrown < neededPots) {
            if (throwCounter < throwDelayTicks) {
                throwCounter++;
                return;
            }
            mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
            potThrown++;
            throwCounter = 0;

            if (potThrown < neededPots) {
                targetSlot = hotbarSlots.get(potThrown);
                currentSlot = -1;
            } else {
                reset(mc, true);
            }
        }
    }

    private void tryActivate(Minecraft mc) {
        if (mc.player == null || mc.level == null || activated) return;
        if (mc.player.getHealth() > minHealthHearts * 2.0f) return;

        List<Integer> slots = findSplashHealthIISlots(mc);
        if (slots.isEmpty()) return;

        neededPots = Math.min(Math.max(1, requiredPotions), slots.size());
        hotbarSlots.clear();
        hotbarSlots.addAll(slots);
        activated = true;
        potThrown = 0;
        pitchSaved = false;
        switchCounter = 0;
        throwCounter = 0;
        originalSlot = mc.player.getInventory().selected;
        currentSlot = originalSlot;
        targetSlot = slots.get(0);
    }

    private void switchSlot(Minecraft mc, int slot) {
        if (mc.player == null || slot < 0 || slot > 8) return;
        mc.player.getInventory().selected = slot;
        mc.player.connection.send(new ServerboundSetCarriedItemPacket(slot));
    }

    private void reset(Minecraft mc, boolean restoreSlot) {
        if (mc.player != null) {
            if (lookDown && pitchSaved) mc.player.setXRot(originalPitch);
            if (restoreSlot && switchBack && originalSlot >= 0 && originalSlot <= 8) {
                switchSlot(mc, originalSlot);
            }
        }
        activated = false;
        potThrown = 0;
        neededPots = 2;
        currentSlot = -1;
        targetSlot = -1;
        originalSlot = -1;
        pitchSaved = false;
        switchCounter = 0;
        throwCounter = 0;
        hotbarSlots.clear();
    }

    private List<Integer> findSplashHealthIISlots(Minecraft mc) {
        List<Integer> found = new ArrayList<>();
        Inventory inventory = mc.player.getInventory();
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = inventory.getItem(slot);
            if (stack.isEmpty() || !stack.is(Items.SPLASH_POTION)) continue;
            PotionContents contents = stack.get(DataComponents.POTION_CONTENTS);
            if (contents == null) continue;
            for (MobEffectInstance effect : contents.getAllEffects()) {
                Holder<MobEffect> type = effect.getEffect();
                if (type.is(MobEffects.HEAL) && effect.getAmplifier() >= 1) {
                    found.add(slot);
                    break;
                }
            }
        }
        return found;
    }
}
