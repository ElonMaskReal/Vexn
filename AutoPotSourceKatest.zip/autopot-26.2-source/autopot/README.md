# AutoPot — Minecraft 26.2 (Fabric)

This source project has been migrated from the supplied Minecraft 1.21.1/Yarn project to the Minecraft 26.2 unobfuscated Mojang-name toolchain.

## Requirements
- Minecraft 26.2
- Fabric Loader 0.19.3 or newer
- Fabric API 0.152.2+26.2
- Java 25
- Gradle 9.5.1 (the wrapper distribution is configured)

## Build
Run `gradle build` (or `./gradlew build` after adding the standard Gradle wrapper launcher scripts/JAR).
The output is written to `build/libs/`.

## Use
- Press **G** to activate while health is at or below the configured threshold.
- The module scans hotbar slots 1–9 for Splash Potion of Healing II.
- Settings are stored in `config/autopot.json` and can be edited while the game is closed.

This is a standalone Fabric client mod, not yet integrated into the Zeexty client JAR. Runtime behavior has not been tested in-game.
